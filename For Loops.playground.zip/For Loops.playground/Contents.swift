import UIKit

var str = "Hello, playground"

for count in 0...10 {
    print(count)
}

print("TUBBIES CHALLENGE")
print("CLOSED RANGE")
var tubbies = ["Tinky Winky", "Dipsy", "Lala", "Po"]

//CLOSED RANGE
for tubbyNumber in 0...3{
    print(tubbies[tubbyNumber])
}

print("\nHALF OPEN RANGE")
//HALF OPEN RANGE
for tubbyNumber in 0..<tubbies.count-1 {
    print(tubbies[tubbyNumber])
}

print("\nITERATE THROUGH AN ARRAY")
for tubby in tubbies{
    print(tubby)
}

print("\nAVERAGE CHALLENGE")
var quizzes = [72, 81, 89, 95, 92]
var total = 0

for quizNumber in 0...quizzes.count-1 {
    total = total + quizzes[quizNumber]
}
print("total = \(total),quizzes.count = \(quizzes.count), average = \(Double(total)/Double(quizzes.count))")

print("half open range")
total = 0
for quizNumber in 0..<quizzes.count {
    total = total + quizzes[quizNumber]
}
print("total = \(total),quizzes.count = \(quizzes.count), average = \(Double(total)/Double(quizzes.count))")

print("\niterate through array")
total = 0
for quiz in quizzes{
    total = total + quiz
}
print("total = \(total),quizzes.count = \(quizzes.count), average = \(Double(total)/Double(quizzes.count))")

//print("\nTYPE MATH")
//with Ints. Unexpected result
//let numerator = 17
//let denominator = 2
//let result = numerator / denominator
//print ("numberator / denominator = \(result)")
//8

//print("\nimplicit declaration")
//let numerator = 17.0
//let denominator = 2.0
//let result = numerator / denominator
//print("numerator / denominator = \(result)")
//8.5


//print("\nexplicit declaration")
//let numerator: Double = 17
//let denominator: Double = 2
//let result = numerator / denominator
//print("numerator / denominator = \(result)")
//8.5

//print("\type conversion")
//let numerator = 17
//let denominator = 2
//let result = Double(numerator) / Double(denominator)
//print("numerator / denominator = \(result)")

//print("\nREMAINDER OPERATOR %")
//let numerator = 17
//let denominator = 3
//print("numerator / denominator = \(numerator / denominator)")
//print("numerator % denominator = \(numerator % denominator)")

//print("\nIS ODD CHALLENGE")
//let value = 135792
//if value % 2 == 0 {
//    print("\(value) is even")
//}else{
//    print("\(value) is odd")
//}

print("\nWINTER OLYMPIC YEAR CHALLENGE")
let year = 2022
let woYear = 2018

if (year - woYear) % 4 == 0 {
    print("\(year) will be a Winter Olympic Year")
}else{
    print("\(year) will not be a Winter Olympic Year. You'll have to wait \(4 - ((year-woYear) % 4)) more years")
}

print("\nLIKE SWIFT CHALLENGE")
var howMuchLiked = 1
var likePhrase = ""
for likeCount in 1...howMuchLiked {
    likePhrase = likePhrase + " really"
}
print("I\(likePhrase) like Swift")

print("\nCOUNTDOWN")
for count in (0...10).reversed() {
    print(count)
}

print("\nSTIRDE")
//Count by fours to list the next few Olympic years, starting with 2020.
//for year in stride(from: 2020, through: 2050, by: 4){
//print(year)
//}

//to means go up to, but don't include this value. Sort of like half-open range
for year in stride(from: 2020, to: 2048, by: 4){
print(year)
}

print("\nBACKWARD STRIDE")
let earlyOlympicYear = 1982
for year in stride(from: 2020, through: earlyOlympicYear, by:-4){
    print(year)
}
print("\nMAKE TEAMS")
var students = ["Harry", "Hermione", "Ron", "Ginny", "Luna", "Viktor"]
var team1: [String] = []
var team2: [String] = []

for index in stride(from:0, to:students.count, by:2) {
    team1.append(students[index])
    team2.append(students[index+1])
}
print("team1 = \(team1)")
print("team2 = \(team2)")
 

